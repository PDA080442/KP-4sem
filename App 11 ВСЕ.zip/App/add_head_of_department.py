from database.database import Database

# Инициализация базы данных
db = Database()

# Добавление нового зав. кафедры
db.add_employee(
    first_name="Иван",
    last_name="Иванов",
    phone="9876543210",
    role="head_of_department",  # Роль зав. кафедры
    degree="Кандидат наук",     # Пример учёной степени
    position=None,              # Не обязательно для зав. кафедры
    title=None,                 # Не обязательно для зав. кафедры
    salary=150000,              # Укажите оклад
    password="12345"            # Задаем пароль
)

print("Сотрудник с ролью 'head_of_department' успешно добавлен в базу данных.")
