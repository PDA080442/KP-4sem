# controllers/auth_controller.py

from models.user import Teacher, HeadOfDepartment, SupportStaff
from database.database import Database

class AuthController:
    def __init__(self):
        self.db = Database()
        
    def authenticate(self, first_name, last_name, password):
        """Проверяет логин и пароль пользователя и возвращает объект пользователя при успешной аутентификации."""
        user_data = self.db.get_user_by_credentials(first_name, last_name, password)
        
        if user_data:
            return self.create_user_instance(user_data)
        return None  # Возвращаем None, если пользователь не найден или пароль неверный

    def register_user(self, user_data):
        """Добавляет нового пользователя в базу данных и возвращает объект пользователя."""
        role = user_data.get("role")
        self.db.add_employee(
            user_data.get("first_name"),
            user_data.get("last_name"),
            user_data.get("phone"),
            role,
            user_data.get("degree"),
            user_data.get("position"),
            user_data.get("title"),
            user_data.get("salary", 0),
            user_data.get("password")
        )
        return self.create_user_instance(user_data)

    def delete_user(self, user):
        """Удаляет пользователя из базы данных."""
        self.db.delete_employee(user.id)

    def create_user_instance(self, user_data):
        """Создает экземпляр пользователя на основе данных из базы данных."""
        role = user_data["role"]
        if role == "teacher":
            return Teacher(**user_data)
        elif role == "head_of_department":
            return HeadOfDepartment(**user_data)
        elif role == "support_staff":
            return SupportStaff(**user_data)
        else:
            raise ValueError("Недопустимая роль пользователя")
