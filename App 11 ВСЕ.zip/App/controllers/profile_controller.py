# controllers/profile_controller.py

from models.user import User
from database.database import Database

class ProfileController:
    def __init__(self, user):
        """
        Инициализирует контроллер профиля для указанного пользователя.
        
        :param user: Текущий пользователь, для которого будет управляться профиль.
        """
        self.user = user
        self.db = Database()

    def get_profile_data(self):
        """
        Возвращает данные профиля текущего пользователя.

        :return: Словарь с данными профиля пользователя.
        """
        return {
            "first_name": self.user.first_name,
            "last_name": self.user.last_name,
            "phone": self.user.phone,
            "role": self.user.role,
            "degree": getattr(self.user, "degree", None),
            "title": getattr(self.user, "title", None),
            "position": getattr(self.user, "position", None),
            "salary": self.user.salary
        }

    def update_profile(self, first_name=None, last_name=None, phone=None):
        """
        Обновляет профиль текущего пользователя и сохраняет изменения в базе данных.

        :param first_name: Новое имя пользователя.
        :param last_name: Новая фамилия пользователя.
        :param phone: Новый номер телефона.
        """
        if first_name:
            self.user.first_name = first_name
        if last_name:
            self.user.last_name = last_name
        if phone:
            self.user.phone = phone

        # Сохраняем изменения в базе данных
        self.db.update_employee(
            self.user.id,
            self.user.first_name,
            self.user.last_name,
            self.user.phone,
            self.user.role,
            getattr(self.user, "degree", None),
            getattr(self.user, "position", None),
            getattr(self.user, "title", None),
            self.user.salary
        )

    def change_password(self, old_password, new_password, confirm_password):
        """
        Меняет пароль пользователя при правильном старом пароле и совпадении нового пароля с подтверждением.

        :param old_password: Старый пароль пользователя.
        :param new_password: Новый пароль.
        :param confirm_password: Подтверждение нового пароля.
        :return: True, если пароль был успешно изменен, иначе False.
        """
        if old_password == self.user.password and new_password == confirm_password:
            self.user.password = new_password
            self.db.update_user_password(self.user.id, new_password)
            return True
        return False

    def delete_profile(self):
        """
        Удаляет текущий профиль пользователя из базы данных.
        """
        self.db.delete_employee(self.user.id)
