from database.database import Database

class StaffController:
    def __init__(self):
        self.db = Database()

    def get_employees(self):
        """
        Получает список всех сотрудников из базы данных.
        
        :return: Список сотрудников.
        """
        return self.db.get_all_employees()

    def add_employee(self, first_name, last_name, phone, role, degree=None, position=None, title=None, salary=0):
        """
        Добавляет нового сотрудника в базу данных.

        :param first_name: Имя сотрудника.
        :param last_name: Фамилия сотрудника.
        :param phone: Телефонный номер сотрудника.
        :param role: Роль сотрудника.
        :param degree: Научная степень (для преподавателей).
        :param position: Должность (для вспомогательного персонала).
        :param title: Звание (для преподавателей).
        :param salary: Оклад сотрудника.
        """
        self.db.add_employee(first_name, last_name, phone, role, degree, position, title, salary)

    def update_employee(self, employee_id, first_name, last_name, phone, role, degree=None, position=None, title=None, salary=0):
        """
        Обновляет данные сотрудника в базе данных.

        :param employee_id: ID сотрудника.
        :param first_name: Имя сотрудника.
        :param last_name: Фамилия сотрудника.
        :param phone: Телефонный номер сотрудника.
        :param role: Роль сотрудника.
        :param degree: Научная степень (для преподавателей).
        :param position: Должность (для вспомогательного персонала).
        :param title: Звание (для преподавателей).
        :param salary: Оклад сотрудника.
        """
        self.db.update_employee(employee_id, first_name, last_name, phone, role, degree, position, title, salary)

    def delete_employee(self, employee_id):
        """
        Удаляет сотрудника по ID.

        :param employee_id: ID сотрудника для удаления.
        """
        self.db.delete_employee(employee_id)
    
    def get_employee_by_id(self, employee_id):
        """
        Получает информацию о сотруднике по его ID.
        
        :param employee_id: ID сотрудника.
        :return: Информация о сотруднике.
        """
        return self.db.get_employee_by_id(employee_id)
