# controllers/task_controller.py

from database.database import Database
from models.task import Task

class TaskController:
    def __init__(self):
        self.database = Database()
    
    def add_additional_task(self, title, complexity, payment, responsible_id, start_date, duration, employee_count, is_urgent):
        """Сохраняет дополнительную задачу с заданными параметрами в базе данных."""
        self.database.add_additional_task(
            title=title,
            complexity=complexity,
            payment=payment,
            responsible_id=responsible_id,
            start_date=start_date,
            duration=duration,
            employee_count=employee_count,
            is_urgent=is_urgent
        )
        
    def complete_additional_task(self, task_id, end_date):
        """Завершает дополнительную задачу и добавляет оплату к окладу ответственного сотрудника."""
        self.database.complete_additional_task(task_id, end_date)
        self.database.delete_additional_task(task_id)  # Удаляем задачу после завершения


    def get_tasks(self):
        """Возвращает список всех задач."""
        db_tasks = self.database.get_all_tasks()
        return [Task(*task) for task in db_tasks]

    def add_task(self, title, description, duration, is_urgent=False):
        """Добавляет новую задачу."""
        self.database.add_task(title, description, duration, is_urgent)

    def remove_task(self, title):
        """Удаляет задачу по названию."""
        task = self.get_task(title)
        if task:
            # Удалим задачу из базы данных по ID
            self.database.delete_task(task.id)

    def get_task(self, title):
        """Получает задачу по названию."""
        tasks = self.get_tasks()
        for task in tasks:
            if task.title == title:
                return task
        return None

    def edit_task(self, old_title, new_title, description, duration, is_urgent):
        """Редактирует существующую задачу."""
        task = self.get_task(old_title)
        if task:
            # Обновляем задачу в базе данных по её ID
            self.database.update_task(task.id, new_title, description, duration, is_urgent)
    
    def add_additional_task(self, title, complexity, payment, responsible_id, start_date, duration, employee_count, is_urgent):
        """Добавляет новую дополнительную задачу в базу данных."""
        self.database.add_additional_task(title, complexity, payment, responsible_id, start_date, duration, employee_count, is_urgent)

    def get_all_additional_tasks(self):
        """Получает все дополнительные задачи и заменяет ID ответственных на имена сотрудников."""
        tasks = self.database.get_all_additional_tasks()
        employee_names = self.database.get_employee_names()

        # Заменяем ID сотрудников на их имена
        tasks_with_names = []
        for task in tasks:
            responsible_ids = str(task[4]).split(",")  # Разделяем ID на случай нескольких сотрудников
            responsible_names = ", ".join([employee_names.get(int(emp_id), "Unknown") for emp_id in responsible_ids])
            task_with_names = (task[0], task[1], task[2], task[3], responsible_names, task[5], task[6])
            tasks_with_names.append(task_with_names)

        return tasks_with_names