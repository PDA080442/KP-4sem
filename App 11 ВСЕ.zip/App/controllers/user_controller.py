from models.teacher import Teacher
from models.head_of_department import HeadOfDepartment
from models.support_staff import SupportStaff
from database.database import Database

class UserController:
    def __init__(self):
        self.db = Database()
        self.users = self.load_users()  # Загружаем пользователей из базы данных

    def load_users(self):
        users = []
        db_users = self.db.get_all_users()
        for user_data in db_users:
            # Следите за правильным порядком:
            user_id, first_name, last_name, phone, role, password, degree, position, title, salary = user_data
            if role == "teacher":
                users.append(Teacher(user_id, first_name, last_name, phone, role, password, degree, title, salary))
            elif role == "head_of_department":
                users.append(HeadOfDepartment(user_id, first_name, last_name, phone, role, password, degree, salary))
            elif role == "support_staff":
                users.append(SupportStaff(user_id, first_name, last_name, phone, role, password, position, salary))
        return users

    
    def find_user(self, first_name, last_name, password):
        """Находит пользователя по имени, фамилии и паролю без хэширования."""
        print(f"Проверка пользователя: {first_name} {last_name} с паролем: {password}")  # Отладочный вывод
        for user in self.users:
            print(f"Сравнение с пользователем: {user.first_name} {user.last_name} и паролем: {user.password}")
            if (user.first_name == first_name and 
                user.last_name == last_name and 
                user.password == password):
                return user
        return None
    
    def update_user(self, user):
        return self.db.update_employee(
            user.id,
            user.first_name,
            user.last_name,
            user.phone,
            user.role,
            getattr(user, 'degree', None),
            getattr(user, 'position', None),
            getattr(user, 'title', None),
            user.salary
        )


    def update_user_password(self, user_id, new_password):
        """Обновляет пароль пользователя в базе данных."""
        return self.db.update_user_password(user_id, new_password)

    def get_user_by_id(self, user_id):
        """Получает пользователя по ID."""
        return self.db.get_user_by_id(user_id)

    def verify_password(self, user_id, current_password):
        """Проверяет, соответствует ли текущий пароль сохраненному в базе."""
        user_data = self.db.get_user_by_id(user_id)
        if user_data:
            stored_password = user_data[9]  # Индекс пароля в структуре данных
            print(f"Хранимый пароль в базе данных: {stored_password}")  # Отладочный вывод
            return stored_password == current_password
        return False