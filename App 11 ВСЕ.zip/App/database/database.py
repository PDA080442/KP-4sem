import sqlite3
import hashlib

class Database:
    def __init__(self, db_name="tasks.db"):
        self.db_name = db_name
        self.connection = None
        self.connect()

    def connect(self):
        """Подключение к базе данных и создание таблиц, если они не существуют."""
        self.connection = sqlite3.connect(self.db_name)
        cursor = self.connection.cursor()
    
        # Создание таблицы для задач
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            duration INTEGER,
            is_urgent BOOLEAN
            )
        ''')

        # Создание таблицы для сотрудников
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            phone TEXT,
            role TEXT,
            degree TEXT,
            position TEXT,
            title TEXT,
            salary INTEGER DEFAULT 0
            )
        ''')
        
        # Добавляем в метод connect
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS additional_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                complexity TEXT CHECK(complexity IN ('легкая', 'средняя', 'тяжелая')),
                payment INTEGER NOT NULL,
                responsible_id INTEGER,
                start_date TEXT,
                end_date TEXT,
                duration INTEGER,
                employee_count INTEGER,
                is_urgent BOOLEAN,
                FOREIGN KEY (responsible_id) REFERENCES employees(id)
            )
        ''')


        # Проверка и добавление столбца 'password', если его нет
        try:
            cursor.execute("ALTER TABLE employees ADD COLUMN password TEXT DEFAULT 'default_password'")
        except sqlite3.OperationalError:
            # Столбец уже существует
            pass

        self.connection.commit()

    def close(self):
        if self.connection:
            self.connection.close()
    
    # Методы для работы с задачами
    def add_task(self, title, description, duration, is_urgent):
        cursor = self.connection.cursor()
        cursor.execute('''
            INSERT INTO tasks (title, description, duration, is_urgent)
            VALUES (?, ?, ?, ?)
        ''', (title, description, duration, is_urgent))
        self.connection.commit()

    def get_all_tasks(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT id, title, description, duration, is_urgent FROM tasks")
        return cursor.fetchall()

    def update_task(self, task_id, title, description, duration, is_urgent):
        cursor = self.connection.cursor()
        cursor.execute('''
            UPDATE tasks
            SET title = ?, description = ?, duration = ?, is_urgent = ?
            WHERE id = ?
        ''', (title, description, duration, is_urgent, task_id))
        self.connection.commit()

    def delete_task(self, task_id):
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        self.connection.commit()
    
    def hash_password(self, password):
        """Функция для хеширования пароля."""
        return hashlib.sha256(password.encode()).hexdigest()

    # Методы для работы с сотрудниками
    def add_employee(self, first_name, last_name, phone, role, degree=None, position=None, title=None, salary=0, password="default_password"):
        cursor = self.connection.cursor()
        cursor.execute('''
            INSERT INTO employees (first_name, last_name, phone, role, degree, position, title, salary, password)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (first_name, last_name, phone, role, degree, position, title, salary, password))
        self.connection.commit()

    def get_all_employees(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM employees")
        return cursor.fetchall()

    def delete_employee(self, employee_id):
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM employees WHERE id = ?", (employee_id,))
        self.connection.commit()

    def update_employee(self, employee_id, first_name, last_name, phone, role, degree=None, position=None, title=None, salary=0):
        cursor = self.connection.cursor()
        cursor.execute('''
            UPDATE employees
            SET first_name = ?, last_name = ?, phone = ?, role = ?, degree = ?, position = ?, title = ?, salary = ?
            WHERE id = ?
        ''', (first_name, last_name, phone, role, degree, position, title, salary, employee_id))
        self.connection.commit()
        return cursor.rowcount > 0  # Возвращает True, если строка была обновлена

    def get_employee_by_id(self, employee_id):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM employees WHERE id = ?", (employee_id,))
        return cursor.fetchone()

    # Методы для работы с пользователями
    def update_user_password(self, user_id, new_password):
        cursor = self.connection.cursor()
        cursor.execute('''
            UPDATE employees
            SET password = ?
            WHERE id = ?
        ''', (new_password, user_id))
        self.connection.commit()
        return cursor.rowcount > 0

    def get_user_by_id(self, user_id):
        """Возвращает пользователя по ID, включая его пароль."""
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM employees WHERE id = ?", (user_id,))
        return cursor.fetchone()
    
    def get_all_users(self):
        """Возвращает всех пользователей для инициализации UserController."""
        cursor = self.connection.cursor()
        cursor.execute("""
            SELECT id, first_name, last_name, phone, role, password, degree, position, title, salary
            FROM employees
        """)
        return cursor.fetchall()


    def update_all_passwords(self, new_password="new_default_password"):
        """Обновляет пароли всех сотрудников в базе данных на новый пароль."""
        cursor = self.connection.cursor()
        cursor.execute('''
            UPDATE employees
            SET password = ?
        ''', (new_password,))
        self.connection.commit()

        
    def complete_additional_task(self, task_id, end_date):
        cursor = self.connection.cursor()
        cursor.execute('''
            UPDATE additional_tasks
            SET end_date = ?
            WHERE id = ?
        ''', (end_date, task_id))
        self.connection.commit()

    def delete_additional_task(self, task_id):
        """Удаляет задачу из базы данных по её ID."""
        cursor = self.connection.cursor()
        cursor.execute('DELETE FROM additional_tasks WHERE id = ?', (task_id,))
        self.connection.commit()
    
    def calculate_payment(self, employee_id, task_id):
        cursor = self.connection.cursor()
        cursor.execute("SELECT payment, duration FROM additional_tasks WHERE id = ?", (task_id,))
        task = cursor.fetchone()
        if task:
            payment, duration = task
            additional_payment = payment * (duration / 30)
            cursor.execute("UPDATE employees SET salary = salary + ? WHERE id = ?", (additional_payment, employee_id))
            self.connection.commit()
    
    def get_all_additional_tasks(self):
        """Получает все дополнительные задачи с ID ответственных сотрудников."""
        cursor = self.connection.cursor()
        cursor.execute('SELECT id, title, complexity, payment, responsible_id, start_date, duration FROM additional_tasks')
        return cursor.fetchall()
    
    def complete_additional_task(self, task_id, end_date):
        """Обновляет дату завершения для дополнительной задачи и выплачивает сумму ответственному."""
        cursor = self.connection.cursor()
        cursor.execute("SELECT payment, responsible_id FROM additional_tasks WHERE id = ?", (task_id,))
        task = cursor.fetchone()
        if task:
            payment, responsible_id = task
            cursor.execute("UPDATE employees SET salary = salary + ? WHERE id = ?", (payment, responsible_id))
            cursor.execute("UPDATE additional_tasks SET end_date = ? WHERE id = ?", (end_date, task_id))
            self.connection.commit()
    
    def add_additional_task(self, title, complexity, payment, responsible_ids, start_date, duration, employee_count, is_urgent):
        cursor = self.connection.cursor()

        # Преобразуем список ID ответственных сотрудников в строку
        responsible_ids_str = ','.join(map(str, responsible_ids))

        cursor.execute('''
            INSERT INTO additional_tasks (title, complexity, payment, responsible_id, start_date, duration, employee_count, is_urgent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (title, complexity, payment, responsible_ids_str, start_date, duration, employee_count, is_urgent))
    
        self.connection.commit()    
    
    def get_employee_names(self):
        """Возвращает словарь с именами сотрудников, где ключ - ID сотрудника, а значение - имя и фамилия."""
        cursor = self.connection.cursor()
        cursor.execute('SELECT id, first_name, last_name FROM employees')
        employees = cursor.fetchall()
        return {emp[0]: f"{emp[1]} {emp[2]}" for emp in employees}