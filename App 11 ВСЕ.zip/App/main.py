from controllers.user_controller import UserController
from views.login_window import LoginWindow
from PyQt5.QtWidgets import QApplication, QDialog
# from database.database import Database
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))


def main():
    app = QApplication(sys.argv)
    # db = Database()  # Инициализация базы данных
    # db.update_all_passwords("12345")  # Установка нового дефолтного пароля
    # Инициализация контроллера пользователей, работающего только с SQLite
    user_controller = UserController()  

    login_window = LoginWindow(user_controller)
    if login_window.exec_() == QDialog.Accepted:
        # Открываем главное окно после успешного входа
        main_window = login_window.main_window  # Используем экземпляр из login_window
        main_window.show()
        app.exec_()  # Запускаем основной цикл приложения для удержания окна открытым

if __name__ == "__main__":
    main()
