from models.user import User

class HeadOfDepartment(User):
    """
    Класс HeadOfDepartment представляет заведующего кафедрой.
    """
    def __init__(self, user_id, first_name, last_name, phone=None, role="head_of_department", password=None, degree=None, salary=0):
        super().__init__(user_id, first_name, last_name, phone, role, password, salary)
        self.degree = degree

    def to_dict(self):
        data = super().to_dict()
        data.update({"degree": self.degree})
        return data
