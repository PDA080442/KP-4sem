from models.user import User

class SupportStaff(User):
    """
    Класс SupportStaff представляет учебно-вспомогательный персонал.
    """
    def __init__(self, user_id, first_name, last_name, phone=None, role="support_staff", password=None, position=None, salary=0):
        super().__init__(user_id, first_name, last_name, phone, role, password, salary)
        self.position = position

    def to_dict(self):
        data = super().to_dict()
        data.update({"position": self.position})
        return data
