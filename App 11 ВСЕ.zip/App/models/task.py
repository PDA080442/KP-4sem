# models/task.py

class Task:
    """
    Класс Task представляет задачу с идентификатором, заголовком, описанием, длительностью и
    атрибутом срочности.
    """
    
    def __init__(self, id, title, description, duration, is_urgent=False):
        """
        Инициализирует экземпляр задачи.

        :param id: Идентификатор задачи в базе данных.
        :param title: Заголовок задачи.
        :param description: Описание задачи.
        :param duration: Продолжительность задачи.
        :param is_urgent: Флаг срочности задачи (по умолчанию False).
        """
        self.id = id  # добавляем id как параметр
        self.title = title
        self.description = description
        self.duration = duration
        self.is_urgent = is_urgent

    def __repr__(self):
        """
        Возвращает строковое представление объекта задачи.
        """
        return f"Task(id={self.id}, title={self.title}, duration={self.duration}, urgent={self.is_urgent})"

    def to_dict(self):
        """
        Преобразует данные задачи в словарь.

        :return: Словарь с данными задачи.
        """
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "duration": self.duration,
            "is_urgent": self.is_urgent
        }
