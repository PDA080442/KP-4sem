from models.user import User

class Teacher(User):
    """
    Класс Teacher представляет преподавателя, наследующего основные свойства пользователя
    и добавляющего атрибуты ученой степени и звания.
    """
    
    def __init__(self, user_id, first_name, last_name, phone=None, role="teacher", password=None, degree=None, title=None, salary=0):
        super().__init__(user_id, first_name, last_name, phone, role, password, salary)
        self.degree = degree
        self.title = title

    def to_dict(self):
        data = super().to_dict()
        data.update({
            "degree": self.degree,
            "title": self.title
        })
        return data