# models/user.py

class User:
    """
    Базовый класс User для представления общего пользователя.
    """
    def __init__(self, id, first_name, last_name, phone, role, password, salary=0):
        """
        Инициализирует экземпляр пользователя.

        :param id: Идентификатор пользователя.
        :param first_name: Имя.
        :param last_name: Фамилия.
        :param phone: Номер телефона.
        :param role: Роль пользователя.
        :param password: Пароль пользователя.
        :param salary: Оклад пользователя.
        """
        self.id = id
        self.first_name = first_name
        self.last_name = last_name
        self.phone = phone
        self.role = role
        self.password = password
        self.salary = salary  # Добавляем поле для оклада

    def to_dict(self):
        """
        Преобразует объект пользователя в словарь для сохранения или передачи.

        :return: Словарь с данными пользователя.
        """
        return {
            "id": self.id,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "phone": self.phone,
            "role": self.role,
            "password": self.password,
            "salary": self.salary
        }

class Teacher(User):
    """
    Класс Teacher для представления преподавателя.
    """
    def __init__(self, id, first_name, last_name, phone, password, degree=None, title=None, salary=0):
        super().__init__(id, first_name, last_name, phone, "teacher", password, salary=salary)
        self.degree = degree
        self.title = title

    def to_dict(self):
        data = super().to_dict()
        data.update({"degree": self.degree, "title": self.title})
        return data

class HeadOfDepartment(User):
    """
    Класс HeadOfDepartment для представления заведующего кафедрой.
    """
    def __init__(self, id, first_name, last_name, phone, password, degree=None, salary=0):
        super().__init__(id, first_name, last_name, phone, "head_of_department", password, salary=salary)
        self.degree = degree

    def to_dict(self):
        data = super().to_dict()
        data.update({"degree": self.degree})
        return data

class SupportStaff(User):
    """
    Класс SupportStaff для представления учебно-вспомогательного персонала.
    """
    def __init__(self, id, first_name, last_name, phone, password, position=None, salary=0):
        super().__init__(id, first_name, last_name, phone, "support_staff", password, salary=salary)
        self.position = position

    def to_dict(self):
        data = super().to_dict()
        data.update({"position": self.position})
        return data
