import sqlite3

# Подключаемся к базе данных
connection = sqlite3.connect("tasks.db")
cursor = connection.cursor()

# Обновляем пароли для нужных пользователей
cursor.execute("UPDATE employees SET password = '12345' WHERE first_name = 'И' AND last_name = 'И'")

# Сохраняем изменения и закрываем подключение
connection.commit()
connection.close()
