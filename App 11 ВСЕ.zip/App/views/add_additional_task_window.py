from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QLabel, QLineEdit, QComboBox, QPushButton, 
                             QDateEdit, QSpinBox, QCheckBox, QListWidget, QListWidgetItem)
from PyQt5.QtCore import QDate, Qt

class AddAdditionalTaskWindow(QDialog):
    def __init__(self, task_controller, staff_controller):
        super().__init__()
        self.task_controller = task_controller
        self.staff_controller = staff_controller
        self.setWindowTitle("Добавить дополнительную нагрузку")

        layout = QVBoxLayout()

        # Название задачи
        layout.addWidget(QLabel("Название задачи"))
        self.title_input = QLineEdit()
        layout.addWidget(self.title_input)

        # Выбор сложности
        layout.addWidget(QLabel("Сложность"))
        self.complexity_input = QComboBox()
        self.complexity_input.addItems(["легкая", "средняя", "тяжелая"])
        layout.addWidget(self.complexity_input)

        # Список сотрудников для выбора ответственных
        layout.addWidget(QLabel("Ответственные сотрудники"))
        self.responsible_list = QListWidget()
        self.responsible_list.setSelectionMode(QListWidget.MultiSelection)  # Позволяет множественный выбор
        employees = self.staff_controller.get_employees()
        for emp in employees:
            item = QListWidgetItem(f"{emp[1]} {emp[2]}")
            item.setData(Qt.UserRole, emp[0])  # Сохраняем ID сотрудника
            self.responsible_list.addItem(item)
        layout.addWidget(self.responsible_list)

        # Дата начала
        layout.addWidget(QLabel("Дата начала"))
        self.start_date_input = QDateEdit()
        self.start_date_input.setDate(QDate.currentDate())
        layout.addWidget(self.start_date_input)

        # Длительность
        layout.addWidget(QLabel("Длительность (дни)"))
        self.duration_input = QSpinBox()
        self.duration_input.setRange(1, 365)
        layout.addWidget(self.duration_input)

        # Срочная работа
        self.urgent_checkbox = QCheckBox("Срочная задача")
        layout.addWidget(self.urgent_checkbox)

        # Кнопка добавления
        add_button = QPushButton("Добавить задачу")
        add_button.clicked.connect(self.add_task)
        layout.addWidget(add_button)

        self.setLayout(layout)

    def add_task(self):
        title = self.title_input.text()
        complexity = self.complexity_input.currentText()
        payment = {"легкая": 3000, "средняя": 5000, "тяжелая": 10000}[complexity]

        # Получаем ID выбранных ответственных сотрудников
        responsible_ids = [self.responsible_list.item(i).data(Qt.UserRole) 
                           for i in range(self.responsible_list.count()) 
                           if self.responsible_list.item(i).isSelected()]

        start_date = self.start_date_input.date().toString("yyyy-MM-dd")
        duration = self.duration_input.value()
        is_urgent = self.urgent_checkbox.isChecked()

        # Передаем список ID ответственных сотрудников в контроллер
        self.task_controller.add_additional_task(title, complexity, payment, responsible_ids, start_date, duration, len(responsible_ids), is_urgent)
        self.accept()
