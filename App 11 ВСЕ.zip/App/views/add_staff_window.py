from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QComboBox

class AddStaffWindow(QDialog):
    def __init__(self, staff_controller):
        super().__init__()
        self.staff_controller = staff_controller
        self.setWindowTitle("Добавить сотрудника")

        layout = QVBoxLayout()

        # Поля для ввода данных сотрудника
        self.first_name_input = QLineEdit()
        self.first_name_input.setPlaceholderText("Имя")
        layout.addWidget(QLabel("Имя"))
        layout.addWidget(self.first_name_input)

        self.last_name_input = QLineEdit()
        self.last_name_input.setPlaceholderText("Фамилия")
        layout.addWidget(QLabel("Фамилия"))
        layout.addWidget(self.last_name_input)

        self.phone_input = QLineEdit()
        self.phone_input.setPlaceholderText("Телефон")
        layout.addWidget(QLabel("Телефон"))
        layout.addWidget(self.phone_input)

        self.role_input = QComboBox()
        self.role_input.addItems(["teacher", "head_of_department", "support_staff"])
        layout.addWidget(QLabel("Роль"))
        layout.addWidget(self.role_input)

        self.degree_input = QLineEdit()
        self.degree_input.setPlaceholderText("Ученая степень (если применимо)")
        layout.addWidget(QLabel("Ученая степень"))
        layout.addWidget(self.degree_input)

        self.position_input = QLineEdit()
        self.position_input.setPlaceholderText("Должность (если применимо)")
        layout.addWidget(QLabel("Должность"))
        layout.addWidget(self.position_input)

        self.salary_input = QLineEdit()
        self.salary_input.setPlaceholderText("Оклад")
        layout.addWidget(QLabel("Оклад"))
        layout.addWidget(self.salary_input)

        # Кнопка для добавления сотрудника
        add_button = QPushButton("Добавить сотрудника")
        add_button.clicked.connect(self.add_employee)
        layout.addWidget(add_button)

        self.setLayout(layout)
        
    def add_employee(self):
        first_name = self.first_name_input.text()
        last_name = self.last_name_input.text()
        phone = self.phone_input.text()
        role = self.role_input.currentText()
        degree = self.degree_input.text() if role == "teacher" or role == "head_of_department" else None
        position = self.position_input.text() if role == "support_staff" else None
        salary = int(self.salary_input.text()) if self.salary_input.text() else 0

        # Добавление сотрудника через контроллер
        self.staff_controller.add_employee(first_name, last_name, phone, role, degree, position, None, salary)
        self.accept()


    def save_employee(self):
        first_name = self.first_name_input.text()
        last_name = self.last_name_input.text()
        phone = self.phone_input.text()
        role = self.role_input.currentText()
        degree_position = self.degree_position_input.text()

        if role == "teacher":
            self.staff_controller.add_employee(first_name, last_name, phone, role, degree=degree_position)
        else:
            self.staff_controller.add_employee(first_name, last_name, phone, role, position=degree_position)

        self.accept()
