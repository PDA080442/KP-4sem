# views/add_task_window.py

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QCheckBox, QMessageBox

class AddTaskWindow(QDialog):
    """
    Окно для добавления новой задачи. Позволяет ввести название, описание, длительность
    и отметить, является ли задача срочной.
    """
    
    def __init__(self, task_controller):
        """
        Инициализирует окно добавления задачи.

        :param task_controller: Экземпляр TaskController для управления задачами.
        """
        super().__init__()
        self.task_controller = task_controller
        self.setWindowTitle("Добавить задачу")

        # Поля ввода для задачи
        self.title_input = QLineEdit()
        self.description_input = QLineEdit()
        self.duration_input = QLineEdit()
        self.urgent_checkbox = QCheckBox("Срочная задача")

        # Кнопка для добавления задачи
        self.add_button = QPushButton("Добавить")
        self.add_button.clicked.connect(self.add_task)

        # Устанавливаем макет
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Название задачи:"))
        layout.addWidget(self.title_input)
        layout.addWidget(QLabel("Описание задачи:"))
        layout.addWidget(self.description_input)
        layout.addWidget(QLabel("Длительность (в часах):"))
        layout.addWidget(self.duration_input)
        layout.addWidget(self.urgent_checkbox)
        layout.addWidget(self.add_button)

        self.setLayout(layout)

    def add_task(self):
        """
        Проверяет корректность ввода данных, создает и сохраняет задачу, если
        все поля заполнены правильно.
        """
        title = self.title_input.text().strip()
        description = self.description_input.text().strip()
        duration = self.duration_input.text().strip()
        is_urgent = self.urgent_checkbox.isChecked()

        # Проверка корректности ввода
        if title and description and duration.isdigit():
            self.task_controller.add_task(title, description, int(duration), is_urgent)
            QMessageBox.information(self, "Успех", "Задача успешно добавлена.")
            self.accept()  # Закрываем окно после добавления задачи
        else:
            # Сообщение об ошибке
            error_dialog = QMessageBox(self)
            error_dialog.setIcon(QMessageBox.Warning)
            error_dialog.setWindowTitle("Ошибка")
            error_dialog.setText("Пожалуйста, заполните все поля корректно.")
            error_dialog.exec_()
