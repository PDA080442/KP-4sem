# views/change_password_window.py

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox

class ChangePasswordWindow(QDialog):
    def __init__(self, user_controller, user_id):
        super().__init__()
        self.user_controller = user_controller
        self.user_id = user_id
        self.setWindowTitle("Смена пароля")

        layout = QVBoxLayout()

        # Поле для текущего пароля
        self.current_password_input = QLineEdit()
        self.current_password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(QLabel("Текущий пароль"))
        layout.addWidget(self.current_password_input)

        # Поле для нового пароля
        self.new_password_input = QLineEdit()
        self.new_password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(QLabel("Новый пароль"))
        layout.addWidget(self.new_password_input)

        # Поле для подтверждения нового пароля
        self.confirm_password_input = QLineEdit()
        self.confirm_password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(QLabel("Подтвердите новый пароль"))
        layout.addWidget(self.confirm_password_input)

        # Кнопка для сохранения нового пароля
        save_button = QPushButton("Сменить пароль")
        save_button.clicked.connect(self.change_password)
        layout.addWidget(save_button)

        self.setLayout(layout)

    def change_password(self):
        current_password = self.current_password_input.text()
        new_password = self.new_password_input.text()
        confirm_password = self.confirm_password_input.text()

        # Проверка текущего пароля
        if not self.user_controller.verify_password(self.user_id, current_password):
            QMessageBox.warning(self, "Ошибка", "Текущий пароль неверен.")
            return

        # Проверка совпадения нового пароля
        if new_password != confirm_password:
            QMessageBox.warning(self, "Ошибка", "Новый пароль и подтверждение не совпадают.")
            return

        # Обновление пароля
        if self.user_controller.update_user_password(self.user_id, new_password):
            QMessageBox.information(self, "Успех", "Пароль успешно изменен.")
            self.accept()
        else:
            QMessageBox.warning(self, "Ошибка", "Не удалось изменить пароль.")
