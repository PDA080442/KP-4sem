# views/delete_staff_window.py

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QComboBox, QPushButton, QMessageBox
from controllers.staff_controller import StaffController

class DeleteStaffWindow(QDialog):
    """
    Окно для удаления сотрудника. Пользователь выбирает сотрудника из списка
    и подтверждает удаление.
    """
    
    def __init__(self, staff_controller):
        """
        Инициализирует окно удаления сотрудника.

        :param staff_controller: Экземпляр StaffController для управления сотрудниками.
        """
        super().__init__()
        self.staff_controller = staff_controller
        self.setWindowTitle("Удалить сотрудника")

        # Поле для выбора сотрудника
        self.staff_selector = QComboBox()
        self.update_staff_list()

        # Кнопка для удаления сотрудника
        self.delete_button = QPushButton("Удалить")
        self.delete_button.clicked.connect(self.delete_staff)

        # Устанавливаем макет
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Выберите сотрудника для удаления:"))
        layout.addWidget(self.staff_selector)
        layout.addWidget(self.delete_button)

        self.setLayout(layout)

    def update_staff_list(self):
        """
        Обновляет выпадающий список сотрудников.
        """
        self.staff_selector.clear()
        staff_list = self.staff_controller.get_staff()
        if staff_list:
            for staff in staff_list:
                # Отображаем фамилию и имя для удобства выбора
                self.staff_selector.addItem(f"{staff['last_name']} {staff['first_name']}", staff["id"])
        else:
            self.staff_selector.addItem("Нет сотрудников", None)
            self.delete_button.setEnabled(False)

    def delete_staff(self):
        """
        Удаляет выбранного сотрудника после подтверждения.
        """
        selected_staff_id = self.staff_selector.currentData()
        if selected_staff_id is None:
            QMessageBox.warning(self, "Ошибка", "Не выбран сотрудник для удаления.")
            return

        # Подтверждение удаления
        reply = QMessageBox.question(self, "Подтверждение", "Вы уверены, что хотите удалить этого сотрудника?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            success = self.staff_controller.delete_staff(selected_staff_id)
            if success:
                QMessageBox.information(self, "Успех", "Сотрудник успешно удален.")
                self.update_staff_list()  # Обновить список после удаления
            else:
                QMessageBox.warning(self, "Ошибка", "Не удалось удалить сотрудника.")
