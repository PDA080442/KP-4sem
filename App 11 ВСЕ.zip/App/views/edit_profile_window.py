# views/edit_profile_window.py

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox

class EditProfileWindow(QDialog):
    def __init__(self, user, user_controller):
        super().__init__()
        self.user = user
        self.user_controller = user_controller

        self.setWindowTitle("Редактирование информации профиля")

        layout = QVBoxLayout()

        # Поля для редактирования информации
        layout.addWidget(QLabel("Имя:"))
        self.first_name_input = QLineEdit(self.user.first_name)
        layout.addWidget(self.first_name_input)

        layout.addWidget(QLabel("Фамилия:"))
        self.last_name_input = QLineEdit(self.user.last_name)
        layout.addWidget(self.last_name_input)

        layout.addWidget(QLabel("Телефон:"))
        self.phone_input = QLineEdit(self.user.phone)
        layout.addWidget(self.phone_input)

        # Поля для ученой степени и должности, если они применимы к пользователю
        if hasattr(self.user, 'degree'):
            layout.addWidget(QLabel("Учёная степень:"))
            self.degree_input = QLineEdit(self.user.degree or "")
            layout.addWidget(self.degree_input)

        if hasattr(self.user, 'title'):
            layout.addWidget(QLabel("Должность:"))
            self.title_input = QLineEdit(self.user.title or "")
            layout.addWidget(self.title_input)

        # Кнопки сохранения и отмены
        save_button = QPushButton("Сохранить")
        save_button.clicked.connect(self.save_profile)
        layout.addWidget(save_button)

        cancel_button = QPushButton("Отмена")
        cancel_button.clicked.connect(self.reject)
        layout.addWidget(cancel_button)

        self.setLayout(layout)

    def save_profile(self):
        # Обновляем данные пользователя в экземпляре
        self.user.first_name = self.first_name_input.text().strip()
        self.user.last_name = self.last_name_input.text().strip()
        self.user.phone = self.phone_input.text().strip()

        if hasattr(self.user, 'degree'):
            self.user.degree = self.degree_input.text().strip()

        if hasattr(self.user, 'title'):
            self.user.title = self.title_input.text().strip()

        # Передаем объект пользователя напрямую в метод update_user
        success = self.user_controller.update_user(self.user)

        if success:
            QMessageBox.information(self, "Успех", "Информация успешно обновлена.")
            self.accept()
        else:
            QMessageBox.warning(self, "Ошибка", "Не удалось обновить информацию.")
