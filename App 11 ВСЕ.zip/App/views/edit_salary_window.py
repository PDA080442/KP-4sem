# views/edit_salary_window.py

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox

class EditSalaryWindow(QDialog):
    def __init__(self, employee, user_controller):
        super().__init__()
        self.employee = employee
        self.user_controller = user_controller

        self.setWindowTitle("Редактирование оклада")

        layout = QVBoxLayout()
        layout.addWidget(QLabel(f"Сотрудник: {employee.first_name} {employee.last_name}"))

        layout.addWidget(QLabel("Оклад:"))
        self.salary_input = QLineEdit(str(employee.salary))
        layout.addWidget(self.salary_input)

        save_button = QPushButton("Сохранить")
        save_button.clicked.connect(self.save_salary)
        layout.addWidget(save_button)

        self.setLayout(layout)

    def save_salary(self):
        try:
            new_salary = int(self.salary_input.text())
            self.employee.salary = new_salary
            # Обновляем оклад в базе данных через user_controller
            success = self.user_controller.update_user_salary(self.employee.id, new_salary)
            if success:
                QMessageBox.information(self, "Успех", "Оклад обновлен.")
                self.accept()
            else:
                QMessageBox.warning(self, "Ошибка", "Не удалось обновить оклад.")
        except ValueError:
            QMessageBox.warning(self, "Ошибка", "Введите корректное значение оклада.")
