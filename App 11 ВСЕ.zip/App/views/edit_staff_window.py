from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox

class EditStaffWindow(QDialog):
    def __init__(self, staff_controller, employee_id):
        super().__init__()
        self.staff_controller = staff_controller
        self.employee_id = employee_id
        self.setWindowTitle("Редактировать сотрудника")

        layout = QVBoxLayout()

        # Поля для редактирования информации о сотруднике
        self.first_name_input = QLineEdit()
        layout.addWidget(QLabel("Имя"))
        layout.addWidget(self.first_name_input)

        self.last_name_input = QLineEdit()
        layout.addWidget(QLabel("Фамилия"))
        layout.addWidget(self.last_name_input)

        self.phone_input = QLineEdit()
        layout.addWidget(QLabel("Телефон"))
        layout.addWidget(self.phone_input)

        self.role_input = QLineEdit()
        layout.addWidget(QLabel("Роль"))
        layout.addWidget(self.role_input)

        self.degree_position_input = QLineEdit()
        layout.addWidget(QLabel("Степень/Должность"))
        layout.addWidget(self.degree_position_input)

        # Поле для редактирования оклада
        self.salary_input = QLineEdit()
        layout.addWidget(QLabel("Оклад"))
        layout.addWidget(self.salary_input)

        # Кнопка для сохранения изменений
        save_button = QPushButton("Сохранить")
        save_button.clicked.connect(self.save_changes)
        layout.addWidget(save_button)

        self.setLayout(layout)

        # Загрузка данных о сотруднике
        self.load_employee_data()

    def load_employee_data(self):
        """Загружает информацию о сотруднике для редактирования."""
        employee = self.staff_controller.get_employee_by_id(self.employee_id)
        print("Загружаемый сотрудник:", employee)  # Отладочный вывод

        if employee:
            self.first_name_input.setText(employee[1])  # Имя
            self.last_name_input.setText(employee[2])   # Фамилия
            self.phone_input.setText(employee[3])       # Телефон
            self.role_input.setText(employee[4])        # Роль
            self.degree_position_input.setText(employee[5] if employee[4] == "teacher" else employee[6])  # Степень или должность
            self.salary_input.setText(str(employee[9]))  # Оклад

    def save_changes(self):
        """Сохраняет изменения сотрудника в базе данных."""
        first_name = self.first_name_input.text()
        last_name = self.last_name_input.text()
        phone = self.phone_input.text()
        role = self.role_input.text()
        degree = self.degree_position_input.text() if role == "teacher" else None
        position = self.degree_position_input.text() if role != "teacher" else None
        try:
            salary = int(self.salary_input.text())
        except ValueError:
            QMessageBox.warning(self, "Ошибка", "Оклад должен быть числом.")
            return

        # Обновление сотрудника в базе данных
        self.staff_controller.update_employee(self.employee_id, first_name, last_name, phone, role, degree, position, None, salary)
        QMessageBox.information(self, "Успех", "Данные сотрудника успешно обновлены.")
        self.accept()
