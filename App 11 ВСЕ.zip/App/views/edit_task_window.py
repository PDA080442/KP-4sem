# views/edit_task_window.py

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QCheckBox, QComboBox, QMessageBox

class EditTaskWindow(QDialog):
    """
    Окно для редактирования задачи. Пользователь выбирает задачу, изменяет ее параметры
    и сохраняет изменения.
    """
    
    def __init__(self, task_controller):
        """
        Инициализирует окно редактирования задачи.

        :param task_controller: Экземпляр TaskController для управления задачами.
        """
        super().__init__()
        self.task_controller = task_controller
        self.setWindowTitle("Редактировать задачу")

        # Поле для выбора задачи
        self.task_selector = QComboBox()
        self.task_selector.addItems([task.title for task in self.task_controller.get_tasks()])
        self.task_selector.currentIndexChanged.connect(self.load_task_details)

        # Поля ввода для редактирования задачи
        self.title_input = QLineEdit()
        self.description_input = QLineEdit()
        self.duration_input = QLineEdit()
        self.urgent_checkbox = QCheckBox("Срочная задача")

        # Кнопка для сохранения изменений
        self.save_button = QPushButton("Сохранить изменения")
        self.save_button.clicked.connect(self.save_changes)

        # Устанавливаем макет
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Выберите задачу:"))
        layout.addWidget(self.task_selector)
        layout.addWidget(QLabel("Название задачи:"))
        layout.addWidget(self.title_input)
        layout.addWidget(QLabel("Описание задачи:"))
        layout.addWidget(self.description_input)
        layout.addWidget(QLabel("Длительность (в часах):"))
        layout.addWidget(self.duration_input)
        layout.addWidget(self.urgent_checkbox)
        layout.addWidget(self.save_button)

        self.setLayout(layout)
        
        # Загрузить данные для первой задачи
        if self.task_controller.get_tasks():
            self.load_task_details()

    def load_task_details(self):
        """
        Загружает детали выбранной задачи в поля для редактирования.
        """
        task_title = self.task_selector.currentText()
        task = self.task_controller.get_task(task_title)
        if task:
            self.title_input.setText(task.title)
            self.description_input.setText(task.description)
            self.duration_input.setText(str(task.duration))
            self.urgent_checkbox.setChecked(task.is_urgent)

    def save_changes(self):
        """
        Проверяет корректность введенных данных и сохраняет изменения задачи.
        """
        old_title = self.task_selector.currentText()
        new_title = self.title_input.text().strip()
        description = self.description_input.text().strip()
        duration = self.duration_input.text().strip()
        is_urgent = self.urgent_checkbox.isChecked()

        # Проверка корректности введенных данных
        if new_title and description and duration.isdigit():
            self.task_controller.edit_task(old_title, new_title, description, int(duration), is_urgent)
            QMessageBox.information(self, "Успех", "Изменения задачи успешно сохранены.")
            self.accept()  # Закрываем окно после сохранения изменений
        else:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, заполните все поля корректно.")
