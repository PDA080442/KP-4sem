# views/login_window.py

import sys
from PyQt5.QtWidgets import QApplication, QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox
from controllers.user_controller import UserController
from views.main_window import MainWindow  # Импортируем основное окно

class LoginWindow(QDialog):
    """
    Окно входа, в котором пользователи вводят логин и пароль для доступа к основному окну.
    """

    def __init__(self, user_controller):
        """
        Инициализирует окно входа.

        :param user_controller: Экземпляр UserController для управления пользователями.
        """
        super().__init__()
        self.user_controller = user_controller
        self.setWindowTitle("Вход в систему")

        # Создаем элементы интерфейса
        self.label_login = QLabel("Логин (Имя Фамилия):")
        self.input_login = QLineEdit()
        
        self.label_password = QLabel("Пароль:")
        self.input_password = QLineEdit()
        self.input_password.setEchoMode(QLineEdit.Password)  # Скрываем ввод пароля

        self.button_login = QPushButton("Войти")
        self.button_login.clicked.connect(self.handle_login)

        # Устанавливаем макет
        layout = QVBoxLayout()
        layout.addWidget(self.label_login)
        layout.addWidget(self.input_login)
        layout.addWidget(self.label_password)
        layout.addWidget(self.input_password)
        layout.addWidget(self.button_login)

        self.setLayout(layout)

    def handle_login(self):
        """
        Проверяет введенные логин и пароль, выполняет вход пользователя и открывает главное окно.
        """
        login = self.input_login.text().strip()
        password = self.input_password.text().strip()

        # Разделяем логин на имя и фамилию
        if ' ' in login:
            first_name, last_name = login.split(' ', 1)  # Разделяем по пробелу
        else:
            QMessageBox.warning(self, "Ошибка", "Введите логин в формате 'Имя Фамилия'.")
            return

        # Проверка пользователя
        user = self.user_controller.find_user(first_name, last_name, password)
        if user:
            QMessageBox.information(self, "Успех", f"Добро пожаловать, {user.first_name} {user.last_name}!")
            self.accept()  # Закрываем окно входа
            
            # Открываем основное окно для пользователя и сохраняем его как атрибут
            self.main_window = MainWindow(user)
            self.main_window.show()
        else:
            QMessageBox.warning(self, "Ошибка", "Неверный логин или пароль.")

def run_app():
    """
    Запускает приложение, отображает окно входа и контролирует процесс авторизации.
    """
    app = QApplication(sys.argv)
    user_controller = UserController()  # Инициализируем без файла

    login_window = LoginWindow(user_controller)
    if login_window.exec_() == QDialog.Accepted:
        print("Пользователь успешно вошел.")

if __name__ == "__main__":
    run_app()
