from PyQt5.QtWidgets import (QMainWindow, QLabel, QTabWidget, QVBoxLayout, QWidget, 
                             QPushButton, QComboBox, QMessageBox, QDialog, QLineEdit, 
                             QTableWidget, QTableWidgetItem, QInputDialog)
from PyQt5.QtCore import QDate
from views.add_task_window import AddTaskWindow
from views.edit_task_window import EditTaskWindow
from views.view_task_window import ViewTaskWindow
from views.add_staff_window import AddStaffWindow
from views.edit_staff_window import EditStaffWindow
from controllers.task_controller import TaskController
from controllers.user_controller import UserController
from views.edit_profile_window import EditProfileWindow
from controllers.staff_controller import StaffController
from views.edit_salary_window import EditSalaryWindow
from views.change_password_window import ChangePasswordWindow
from views.add_additional_task_window import AddAdditionalTaskWindow  # Добавьте импорт



class MainWindow(QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.user = user
        print(f"Роль пользователя при инициализации MainWindow: {self.user.role}")  # Отладка роли пользователя
        self.task_controller = TaskController()
        self.user_controller = UserController()
        self.staff_controller = StaffController()
        self.setWindowTitle(f"Добро пожаловать, {user.first_name} {user.last_name}!")

        # Основной виджет и макет
        central_widget = QWidget()
        layout = QVBoxLayout(central_widget)
        
        # Заголовок с именем пользователя и ролью
        self.label_user_info = QLabel(f"Вы вошли как {self.user.role}")
        layout.addWidget(self.label_user_info)

        # Создаем вкладки в зависимости от роли пользователя
        self.tab_widget = QTabWidget()
        layout.addWidget(self.tab_widget)
        self.setCentralWidget(central_widget)

        # Инициализация вкладок для конкретной роли
        self.init_tabs_for_role()

        # Добавляем вкладку "Личный кабинет" для всех пользователей
        self.init_profile_tab()

    def init_tabs_for_role(self):
        if self.user.role == "teacher":
            self.init_teacher_tabs()
        elif self.user.role == "head_of_department":
            self.init_head_of_department_tabs()
        elif self.user.role == "support_staff":
            self.init_support_staff_tabs()

    def init_teacher_tabs(self):
        task_tab = QWidget()
        task_layout = QVBoxLayout(task_tab)

        task_label = QLabel("Список задач преподавателя")
        task_layout.addWidget(task_label)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Поиск по названию задачи...")
        self.search_input.textChanged.connect(self.update_task_selector)
        task_layout.addWidget(self.search_input)

        self.task_selector = QComboBox()
        self.update_task_selector()
        task_layout.addWidget(self.task_selector)

        view_task_button = QPushButton("Просмотреть задачу")
        view_task_button.clicked.connect(self.open_view_task_window)
        task_layout.addWidget(view_task_button)

        refresh_button = QPushButton("Обновить список задач")
        refresh_button.clicked.connect(self.update_task_selector)
        task_layout.addWidget(refresh_button)

        self.tab_widget.addTab(task_tab, "Задачи")
        
        additional_task_tab = QWidget()
        additional_task_layout = QVBoxLayout(additional_task_tab)
        
        task_label = QLabel("Ваши назначенные дополнительные задачи")
        task_layout.addWidget(task_label)

        additional_task_label = QLabel("Назначенные дополнительные задачи")
        additional_task_layout.addWidget(additional_task_label)

        self.teacher_additional_task_list = QTableWidget()
        self.teacher_additional_task_list.setColumnCount(6)
        self.teacher_additional_task_list.setHorizontalHeaderLabels(
            ["ID", "Название", "Сложность", "Оплата", "Дата начала", "Длительность (дни)"]
        )
        additional_task_layout.addWidget(self.teacher_additional_task_list)

        self.tab_widget.addTab(additional_task_tab, "Дополнительные задачи")

        self.load_teacher_additional_tasks()  # Загрузка назначенных дополнительных задач

    
    def load_teacher_additional_tasks(self):
        """Загружает и отображает дополнительные задачи, назначенные текущему преподавателю."""
        self.teacher_additional_task_list.setRowCount(6)
        all_tasks = self.task_controller.get_all_additional_tasks()
        print("Все дополнительные задачи из контроллера:", all_tasks)  # Отладка


        # Фильтруем задачи, назначенные текущему преподавателю (по его user ID)
        teacher_name = f"{self.user.first_name} {self.user.last_name}"
        assigned_tasks = [
            task for task in all_tasks if teacher_name in task[4]
        ]
        print("Назначенные задачи для преподавателя (фильтрованные):", assigned_tasks)  # Отладка

        # Отображаем отфильтрованные задачи в таблице
        for task in assigned_tasks:
            row_position = self.teacher_additional_task_list.rowCount()
            self.teacher_additional_task_list.insertRow(row_position)
            for column, value in enumerate(task[:6]):
                self.teacher_additional_task_list.setItem(row_position, column, QTableWidgetItem(str(value)))
        print("Задачи успешно добавлены в интерфейс для преподавателя.")

        
    def init_head_of_department_tabs(self):
        print("Добавляем вкладку 'Сотрудники'")  # Отладочный вывод

        # Вкладка для задач
        task_tab = QWidget()
        task_layout = QVBoxLayout(task_tab)
        
        add_task_button = QPushButton("Добавить задачу")
        add_task_button.clicked.connect(self.open_add_task_window)
        task_layout.addWidget(add_task_button)

        edit_task_button = QPushButton("Редактировать задачу")
        edit_task_button.clicked.connect(self.open_edit_task_window)
        task_layout.addWidget(edit_task_button)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Поиск по названию задачи...")
        self.search_input.textChanged.connect(self.update_task_selector)
        task_layout.addWidget(self.search_input)

        self.task_selector = QComboBox()
        self.update_task_selector()
        task_layout.addWidget(self.task_selector)

        view_task_button = QPushButton("Просмотреть задачу")
        view_task_button.clicked.connect(self.open_view_task_window)
        task_layout.addWidget(view_task_button)

        delete_task_button = QPushButton("Удалить задачу")
        delete_task_button.clicked.connect(self.delete_task)
        task_layout.addWidget(delete_task_button)

        refresh_button = QPushButton("Обновить список задач")
        refresh_button.clicked.connect(self.update_task_selector)
        task_layout.addWidget(refresh_button)

        clear_all_button = QPushButton("Очистить все задачи")
        clear_all_button.clicked.connect(self.clear_all_tasks)
        task_layout.addWidget(clear_all_button)

        task_label = QLabel("Управление задачами")
        task_layout.addWidget(task_label)
        
        self.tab_widget.addTab(task_tab, "Задачи")

        # Вкладка для сотрудников
        staff_tab = QWidget()
        staff_layout = QVBoxLayout(staff_tab)
        
        self.staff_search_input = QLineEdit()
        self.staff_search_input.setPlaceholderText("Поиск сотрудников по имени, фамилии или роли...")
        self.staff_search_input.textChanged.connect(self.load_staff_data)
        staff_layout.addWidget(self.staff_search_input)
    
        self.staff_table = QTableWidget()
        self.staff_table.setColumnCount(6)
        self.staff_table.setHorizontalHeaderLabels(["ID", "Имя", "Фамилия", "Телефон", "Роль", "Оклад"])
        staff_layout.addWidget(self.staff_table)

        add_employee_button = QPushButton("Добавить сотрудника")
        add_employee_button.clicked.connect(self.open_add_employee_window)
        staff_layout.addWidget(add_employee_button)

        edit_employee_button = QPushButton("Редактировать сотрудника")
        edit_employee_button.clicked.connect(self.open_edit_employee_window)
        staff_layout.addWidget(edit_employee_button)

        delete_employee_button = QPushButton("Удалить сотрудника")
        delete_employee_button.clicked.connect(self.delete_employee)
        staff_layout.addWidget(delete_employee_button)

        # Обновляем данные таблицы сотрудников
        self.load_staff_data()
    
        staff_tab.setLayout(staff_layout)
        self.tab_widget.addTab(staff_tab, "Сотрудники")  # Добавляем вкладку "Сотрудники"
        
        edit_salary_button = QPushButton("Изменить оклад")
        edit_salary_button.clicked.connect(self.open_edit_salary_window)
        staff_layout.addWidget(edit_salary_button)
        
        # Создание вкладки задач
        task_tab = QWidget()
        task_layout = QVBoxLayout(task_tab)

        # Кнопка для добавления дополнительной задачи
        add_additional_task_button = QPushButton("Добавить дополнительную нагрузку")
        add_additional_task_button.clicked.connect(self.open_additional_task_window)
        task_layout.addWidget(add_additional_task_button)

        # Список дополнительных задач
        self.additional_task_list = QTableWidget()
        self.additional_task_list.setColumnCount(6)
        self.additional_task_list.setHorizontalHeaderLabels(["ID", "Название", "Сложность", "Ответственный", "Начало", "Длительность (дни)"])
        task_layout.addWidget(self.additional_task_list)
        self.load_additional_tasks()

        self.tab_widget.addTab(task_tab, "Дополнительные задачи")
        self.load_additional_tasks()
        
        complete_task_button = QPushButton("Завершить задачу")
        complete_task_button.clicked.connect(self.complete_task)
        task_layout.addWidget(complete_task_button)
        

        
    def open_additional_task_window(self):
        """Открывает окно для добавления дополнительной нагрузки."""
        print("Открытие окна для добавления дополнительной задачи")  # Отладочный вывод
        additional_task_window = AddAdditionalTaskWindow(self.task_controller, self.staff_controller)
        if additional_task_window.exec_() == QDialog.Accepted:
            QMessageBox.information(self, "Успех", "Дополнительная задача успешно добавлена.")
            self.load_additional_tasks()  # Обновляем список дополнительных задач
        
    def load_additional_tasks(self):
        """Загружает и отображает список дополнительных задач в таблице, с именами ответственных сотрудников."""
        self.additional_task_list.setRowCount(0)  # Очищаем таблицу перед добавлением данных
        self.additional_task_list.setColumnCount(7)  # Устанавливаем количество колонок
        self.additional_task_list.setHorizontalHeaderLabels(["ID", "Название", "Сложность", "Оплата", "Ответственный", "Начало", "Длительность (дни)"])

        tasks = self.task_controller.get_all_additional_tasks()  # Получаем задачи с именами сотрудников

        for task in tasks:
            task_id = str(task[0])
            title = task[1] if task[1] else "Без названия"
            complexity = task[2]
            payment = str(task[3])
            responsible_names = task[4]  # Здесь уже будут имена ответственных сотрудников
            start_date = task[5]
            duration = str(task[6])

            row_position = self.additional_task_list.rowCount()
            self.additional_task_list.insertRow(row_position)

            self.additional_task_list.setItem(row_position, 0, QTableWidgetItem(task_id))
            self.additional_task_list.setItem(row_position, 1, QTableWidgetItem(title))
            self.additional_task_list.setItem(row_position, 2, QTableWidgetItem(complexity))
            self.additional_task_list.setItem(row_position, 3, QTableWidgetItem(payment))
            self.additional_task_list.setItem(row_position, 4, QTableWidgetItem(responsible_names))
            self.additional_task_list.setItem(row_position, 5, QTableWidgetItem(start_date))
            self.additional_task_list.setItem(row_position, 6, QTableWidgetItem(duration))
    
            
        
        print("=== Конец обработки дополнительных задач ===")

    
    def open_edit_salary_window(self):
        selected_row = self.staff_table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, выберите сотрудника для изменения оклада.")
            return

        employee_id = int(self.staff_table.item(selected_row, 0).text())
        employee = self.staff_controller.get_employee_by_id(employee_id)
    
        # Проверяем, что сотрудник найден
        if employee:
            new_salary, ok = QInputDialog.getInt(self, "Изменить оклад", "Введите новый оклад:", value=int(employee[9]))

            if ok:
                # Обновляем данные сотрудника
                self.staff_controller.update_employee(
                    employee_id=employee_id,
                    first_name=employee[1],
                    last_name=employee[2],
                    phone=employee[3],
                    role=employee[4],
                    degree=employee[5],
                    position=employee[6],
                    title=employee[7],
                    salary=new_salary
                )
                QMessageBox.information(self, "Успех", "Оклад успешно обновлен.")
                self.load_staff_data()  # Перезагрузка данных сотрудников
        else:
            QMessageBox.warning(self, "Ошибка", "Не удалось найти сотрудника.")
        
    def complete_task(self):
        selected_row = self.additional_task_list.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Ошибка", "Выберите задачу для завершения.")
            return

        task_id = int(self.additional_task_list.item(selected_row, 0).text())
        end_date = QDate.currentDate().toString("yyyy-MM-dd")

        self.task_controller.complete_additional_task(task_id, end_date)
        QMessageBox.information(self, "Успех", "Задача завершена, оплата добавлена.")
        self.load_additional_tasks()


    def init_support_staff_tabs(self):
        task_tab = QWidget()
        task_layout = QVBoxLayout(task_tab)
        
        add_task_button = QPushButton("Добавить задачу")
        add_task_button.clicked.connect(self.open_add_task_window)
        task_layout.addWidget(add_task_button)

        edit_task_button = QPushButton("Редактировать задачу")
        edit_task_button.clicked.connect(self.open_edit_task_window)
        task_layout.addWidget(edit_task_button)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Поиск по названию задачи...")
        self.search_input.textChanged.connect(self.update_task_selector)
        task_layout.addWidget(self.search_input)

        self.task_selector = QComboBox()
        self.update_task_selector()
        task_layout.addWidget(self.task_selector)

        view_task_button = QPushButton("Просмотреть задачу")
        view_task_button.clicked.connect(self.open_view_task_window)
        task_layout.addWidget(view_task_button)

        delete_task_button = QPushButton("Удалить задачу")
        delete_task_button.clicked.connect(self.delete_task)
        task_layout.addWidget(delete_task_button)

        refresh_button = QPushButton("Обновить список задач")
        refresh_button.clicked.connect(self.update_task_selector)
        task_layout.addWidget(refresh_button)

        clear_all_button = QPushButton("Очистить все задачи")
        clear_all_button.clicked.connect(self.clear_all_tasks)
        task_layout.addWidget(clear_all_button)

        task_label = QLabel("Управление задачами учебно-вспомогательного персонала")
        task_layout.addWidget(task_label)
        
        self.tab_widget.addTab(task_tab, "Задачи")
        
        # Добавление таблицы для дополнительных задач
        additional_task_tab = QWidget()
        additional_task_layout = QVBoxLayout(additional_task_tab)
        
        additional_task_label = QLabel("Список дополнительных задач")
        additional_task_layout.addWidget(additional_task_label)
        
        
        self.support_staff_additional_task_list = QTableWidget()
        self.support_staff_additional_task_list.setColumnCount(5)
        self.support_staff_additional_task_list.setHorizontalHeaderLabels(["ID", "Название", "Сложность", "Начало", "Длительность"])
        additional_task_layout.addWidget(self.support_staff_additional_task_list)
        
        
        refresh_additional_tasks_button = QPushButton("Обновить список доп. задач")
        refresh_additional_tasks_button.clicked.connect(self.load_support_staff_additional_tasks)
        additional_task_layout.addWidget(refresh_additional_tasks_button)
    
        additional_task_tab.setLayout(additional_task_layout)
        self.tab_widget.addTab(additional_task_tab, "Доп. задачи")  # добавляем вкладку доп. задач
    
        self.load_support_staff_additional_tasks()
        
        
        task_label = QLabel("Список задач учебно-вспомогательного персонала")
        task_layout.addWidget(task_label)
        
    def load_support_staff_additional_tasks(self):
        """Загружает и отображает дополнительные задачи для учебно-вспомогательного персонала."""
        self.support_staff_additional_task_list.setRowCount(0)
        all_tasks = self.task_controller.get_all_additional_tasks()
        print("Все дополнительные задачи из контроллера:", all_tasks)  # Отладка
    
        # Фильтруем задачи, где учебно-вспомогательный персонал является ответственным
        staff_name = f"{self.user.first_name} {self.user.last_name}"
        assigned_tasks = [
            task for task in all_tasks if staff_name in task[4]
        ]
        print("Назначенные задачи для учебно-вспомогательного персонала (фильтрованные):", assigned_tasks)  # Отладка

        for task in assigned_tasks:
            row_position = self.support_staff_additional_task_list.rowCount()
            self.support_staff_additional_task_list.insertRow(row_position)
            for column, value in enumerate(task[:6]):
                self.support_staff_additional_task_list.setItem(row_position, column, QTableWidgetItem(str(value)))

    print("Задачи успешно добавлены в интерфейс для учебно-вспомогательного персонала.")
    
    def init_profile_tab(self):
        profile_tab = QWidget()
        profile_layout = QVBoxLayout(profile_tab)
        
        # Информация о пользователе
        profile_layout.addWidget(QLabel("Личный кабинет"))
        self.first_name_label = QLabel(f"Имя: {self.user.first_name}")
        profile_layout.addWidget(self.first_name_label)
        self.last_name_label = QLabel(f"Фамилия: {self.user.last_name}")
        profile_layout.addWidget(self.last_name_label)
        self.phone_label = QLabel(f"Телефон: {self.user.phone}")
        profile_layout.addWidget(self.phone_label)
        self.role_label = QLabel(f"Роль: {self.user.role}")
        profile_layout.addWidget(self.role_label)
        
        # Добавляем информацию об окладе
        self.salary_label = QLabel(f"Оклад: {self.user.salary} руб.")
        profile_layout.addWidget(self.salary_label)

        # Если роль преподавателя или заведующего, добавить ученую степень
        if hasattr(self.user, 'degree') and self.user.degree:
            self.degree_label = QLabel(f"Учёная степень: {self.user.degree}")
            profile_layout.addWidget(self.degree_label)

        # Если роль преподавателя, добавить должность
        if hasattr(self.user, 'title') and self.user.title:
            self.title_label = QLabel(f"Должность: {self.user.title}")
            profile_layout.addWidget(self.title_label)

        # Кнопка для редактирования профиля
        edit_profile_button = QPushButton("Редактировать информацию")
        edit_profile_button.clicked.connect(self.open_edit_profile_window)
        profile_layout.addWidget(edit_profile_button)
        
        profile_label = QLabel(f"{self.user.first_name} {self.user.last_name} - {self.user.role}")
        profile_layout.addWidget(profile_label)

        # Кнопка смены пароля
        change_password_button = QPushButton("Сменить пароль")
        change_password_button.clicked.connect(self.open_change_password_window)
        profile_layout.addWidget(change_password_button)

        self.tab_widget.addTab(profile_tab, "Личный кабинет")
        
    def open_change_password_window(self):
        change_password_window = ChangePasswordWindow(self.user_controller, self.user.id)
        if change_password_window.exec_() == QDialog.Accepted:
            QMessageBox.information(self, "Успех", "Пароль успешно изменен.")
    
    def open_edit_profile_window(self):
        edit_profile_window = EditProfileWindow(self.user, self.user_controller)
        if edit_profile_window.exec_() == QDialog.Accepted:
            self.update_profile_tab()
    
    def update_profile_tab(self):
        self.first_name_label.setText(f"Имя: {self.user.first_name}")
        self.last_name_label.setText(f"Фамилия: {self.user.last_name}")
        self.phone_label.setText(f"Телефон: {self.user.phone}")
        if hasattr(self.user, 'degree') and self.user.degree:
            self.degree_label.setText(f"Учёная степень: {self.user.degree}")
        if hasattr(self.user, 'title') and self.title_label:
            self.title_label.setText(f"Должность: {self.user.title}")
    
    def update_task_selector(self):
        self.task_selector.clear()
        filter_text = self.search_input.text().lower()
        filtered_tasks = [task.title for task in self.task_controller.get_tasks() if filter_text in task.title.lower()]
        if not filtered_tasks:
            self.task_selector.addItem("Задач нет")
        else:
            self.task_selector.addItems(filtered_tasks)
        
    def load_staff_data(self):
        filter_text = self.staff_search_input.text().lower()
        employees = self.staff_controller.get_employees()
        self.staff_table.setRowCount(0)
        for employee in employees:
            if (filter_text in employee[1].lower() or filter_text in employee[2].lower() or filter_text in employee[4].lower()):
                row_position = self.staff_table.rowCount()
                self.staff_table.insertRow(row_position)
                for column, data in enumerate(employee):
                    self.staff_table.setItem(row_position, column, QTableWidgetItem(str(data)))
                # Добавляем оклад в конец строки
                self.staff_table.setItem(row_position, 7, QTableWidgetItem(str(employee[-1])))  # Оклад на последней позиции

    def open_add_task_window(self):
        add_task_window = AddTaskWindow(self.task_controller)
        if add_task_window.exec_() == QDialog.Accepted:
            self.update_task_selector()

    def open_edit_task_window(self):
        edit_task_window = EditTaskWindow(self.task_controller)
        if edit_task_window.exec_() == QDialog.Accepted:
            self.update_task_selector()

    def open_view_task_window(self):
        task_title = self.task_selector.currentText()
        task = self.task_controller.get_task(task_title)
        if task:
            view_task_window = ViewTaskWindow(task)
            view_task_window.exec_()

    def open_add_employee_window(self):
        add_staff_window = AddStaffWindow(self.staff_controller)
        if add_staff_window.exec_() == QDialog.Accepted:
            self.load_staff_data()

    def open_edit_employee_window(self):
        selected_row = self.staff_table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, выберите сотрудника для редактирования.")
            return
        employee_id = int(self.staff_table.item(selected_row, 0).text())
        edit_staff_window = EditStaffWindow(self.staff_controller, employee_id)
        if edit_staff_window.exec_() == QDialog.Accepted:
            self.load_staff_data()

    def delete_task(self):
        task_title = self.task_selector.currentText()
        reply = QMessageBox.question(self, "Подтверждение", f"Вы уверены, что хотите удалить задачу '{task_title}'?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            self.task_controller.remove_task(task_title)
            self.update_task_selector()

    def delete_employee(self):
        selected_row = self.staff_table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, выберите сотрудника для удаления.")
            return
        employee_id = int(self.staff_table.item(selected_row, 0).text())
        reply = QMessageBox.question(self, "Подтверждение", "Вы уверены, что хотите удалить этого сотрудника?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.staff_controller.delete_employee(employee_id)
            self.load_staff_data()

    def clear_all_tasks(self):
        reply = QMessageBox.question(self, "Подтверждение", "Вы уверены, что хотите очистить все задачи?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.task_controller.clear_all_tasks()
            self.update_task_selector()