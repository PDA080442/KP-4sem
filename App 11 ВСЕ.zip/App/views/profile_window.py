# views/profile_window.py

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QMessageBox, QLineEdit, QFormLayout

class ProfileWindow(QDialog):
    def __init__(self, user, user_controller):
        super().__init__()
        self.user = user
        self.user_controller = user_controller
        self.setWindowTitle("Личный кабинет")

        layout = QVBoxLayout()
        layout.addWidget(QLabel(f"ФИО: {self.user.first_name} {self.user.last_name}"))
        layout.addWidget(QLabel(f"Телефон: {self.user.phone}"))
        layout.addWidget(QLabel(f"Роль: {self.user.role}"))
        
        if self.user.role in ["teacher", "head_of_department"]:
            layout.addWidget(QLabel(f"Ученая степень: {self.user.degree}"))

        # Кнопки управления профилем
        edit_button = QPushButton("Редактировать профиль")
        edit_button.clicked.connect(self.edit_profile)
        delete_button = QPushButton("Удалить профиль")
        delete_button.clicked.connect(self.delete_profile)

        layout.addWidget(edit_button)
        layout.addWidget(delete_button)
        self.setLayout(layout)

    def edit_profile(self):
        # Окно редактирования профиля
        edit_dialog = QDialog(self)
        edit_dialog.setWindowTitle("Редактировать профиль")

        form_layout = QFormLayout()
        
        # Поля для редактирования
        first_name_input = QLineEdit(self.user.first_name)
        last_name_input = QLineEdit(self.user.last_name)
        phone_input = QLineEdit(self.user.phone)
        
        form_layout.addRow("Имя:", first_name_input)
        form_layout.addRow("Фамилия:", last_name_input)
        form_layout.addRow("Телефон:", phone_input)

        save_button = QPushButton("Сохранить")
        save_button.clicked.connect(lambda: self.save_profile_changes(first_name_input, last_name_input, phone_input, edit_dialog))
        form_layout.addWidget(save_button)

        edit_dialog.setLayout(form_layout)
        edit_dialog.exec_()

    def save_profile_changes(self, first_name_input, last_name_input, phone_input, edit_dialog):
        # Сохранение изменений
        self.user.first_name = first_name_input.text().strip()
        self.user.last_name = last_name_input.text().strip()
        self.user.phone = phone_input.text().strip()

        # Обновляем данные пользователя в базе данных через контроллер и закрываем диалог
        if self.user_controller.update_user(self.user):
            QMessageBox.information(self, "Успех", "Профиль успешно обновлен.")
            edit_dialog.accept()
        else:
            QMessageBox.warning(self, "Ошибка", "Не удалось обновить профиль.")

    def delete_profile(self):
        reply = QMessageBox.question(self, "Подтверждение", "Вы уверены, что хотите удалить профиль?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            success = self.user_controller.delete_user(self.user.id)
            if success:
                QMessageBox.information(self, "Успех", "Профиль удален.")
                self.accept()  # Закрываем окно профиля
            else:
                QMessageBox.warning(self, "Ошибка", "Не удалось удалить профиль.")
