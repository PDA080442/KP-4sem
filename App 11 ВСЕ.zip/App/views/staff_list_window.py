# views/staff_list_window.py

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTableWidget, QTableWidgetItem
from controllers.staff_controller import StaffController

class StaffListWindow(QDialog):
    def __init__(self, staff_controller):
        super().__init__()
        self.staff_controller = staff_controller
        self.setWindowTitle("Список сотрудников")

        # Основной макет
        layout = QVBoxLayout()
        
        # Таблица сотрудников
        self.table = QTableWidget()
        self.table.setColumnCount(10)  # Увеличиваем количество колонок до 10 для включения оклада
        self.table.setHorizontalHeaderLabels(["ID", "Имя", "Фамилия", "Отчество", "Телефон", "Роль", "Степень", "Должность", "Звание", "Оклад"])
        layout.addWidget(self.table)

        self.setLayout(layout)
        self.update_staff_table()

    def update_staff_table(self):
        """Обновление таблицы сотрудников с отладочной информацией."""
        self.table.setRowCount(0)
        
        # Получаем список сотрудников и выводим его для отладки
        employees = self.staff_controller.get_employees()
        print("Сотрудники, загруженные из базы данных:", employees)  # Отладочная печать

        for staff in employees:
            row_position = self.table.rowCount()
            self.table.insertRow(row_position)
            self.table.setItem(row_position, 0, QTableWidgetItem(str(staff[0])))  # ID
            self.table.setItem(row_position, 1, QTableWidgetItem(staff[1]))       # Имя
            self.table.setItem(row_position, 2, QTableWidgetItem(staff[2]))       # Фамилия
            self.table.setItem(row_position, 3, QTableWidgetItem(staff[3] or "")) # Отчество
            self.table.setItem(row_position, 4, QTableWidgetItem(staff[4]))       # Телефон
            self.table.setItem(row_position, 5, QTableWidgetItem(staff[5]))       # Роль
            self.table.setItem(row_position, 6, QTableWidgetItem(staff[6] or "")) # Степень
            self.table.setItem(row_position, 7, QTableWidgetItem(staff[7] or "")) # Должность
            self.table.setItem(row_position, 8, QTableWidgetItem(staff[8] or "")) # Звание
            self.table.setItem(row_position, 9, QTableWidgetItem(str(staff[9])))  # Оклад

