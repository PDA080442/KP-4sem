# views/view_task_window.py

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel

class ViewTaskWindow(QDialog):
    def __init__(self, task):
        super().__init__()
        self.task = task
        self.setWindowTitle("Просмотр задачи")

        # Создаем элементы интерфейса для отображения информации о задаче
        layout = QVBoxLayout()
        layout.addWidget(QLabel(f"Название: {self.task.title}"))
        layout.addWidget(QLabel(f"Описание: {self.task.description}"))
        layout.addWidget(QLabel(f"Длительность: {self.task.duration} часов"))
        layout.addWidget(QLabel(f"Срочная: {'Да' if self.task.is_urgent else 'Нет'}"))

        self.setLayout(layout)
